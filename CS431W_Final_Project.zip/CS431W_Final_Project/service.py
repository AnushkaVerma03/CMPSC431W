import pymysql
from flask import redirect, session, render_template
import wtforms
from flask_wtf import FlaskForm
from wtforms import StringField, DateField
from wtforms.validators import InputRequired, Length


def execute_query(query):
    # Connect to the database
    connection = pymysql.connect(host='localhost',
                                 user='anushka',
                                 password='Jeonjungkook97',
                                 db='BookshopDB',
                                 charset='utf8mb4',
                                 cursorclass=pymysql.cursors.DictCursor)
    try:
        # Execute the query
        with connection.cursor() as cursor:
            cursor.execute(query)
            result = cursor.fetchall()
            return result
    except Exception as e:
        return e
    finally:
        connection.close()


def get_books():
    # TODO: Replace this with a call to the database
    books = [
        {'name': "Catcher in the Rye", 'author': "author 1", 'price': 15.99},
        {'name': "To Kill a Mockingbird", 'author': "author 2", 'price': 12.99},
        {'name': "The Lord of the Rings", 'author': "author 3", 'price': 18.99},
        {'name': "The Chroncles of Narnia", 'author': "author 3", 'price': 15.99},
        {'name': "The Oddysey", 'author': "author 3", 'price': 12.99},
        {'name': "Dracula", 'author': "author 3", 'price': 18.99},
        {'name': "Hounds of Baskerville", 'author': "author 3", 'price': 15.99},
        {'name': "The Alchemist", 'author': "author 3", 'price': 12.99},
        {'name': "The Shining", 'author': "author 3", 'price': 15.99},
        {'name': "The Kite Runner", 'author': "author 3", 'price': 13.99},
        {'name': "The Stranger", 'author': "author 3", 'price': 18.99}
    ]
    # Do a join for genre and author
    query = "SELECT * FROM BOOKS"
    books = execute_query(query)
    print(books)
    return books


def get_authors():
    # Get all authors from the database and return as a json
    query = "SELECT * FROM AUTHORS"
    return execute_query(query)


print(get_authors())


def add_recommendation(book_isbn, book_name, author_name, recommendation):
    return execute_query(
        "INSERT INTO RECOMMENDATIONS (ISBN, BOOK_NAME, AUTHOR_NAME, RECOMMENDATION) VALUES ('{}', '{}', '{}', '{}')".
        format(book_isbn, book_name, author_name, recommendation))


def get_book_details_by_isbn(isbn):
    book = execute_query("SELECT * FROM BOOKS WHERE ISBN = '{}'".format(isbn))
    print(book)
    return book

def login_details(username, password):
    query = "SELECT * FROM USERS WHERE USERNAME = '{}' AND PASSWORD = '{}'".format(username, password)
    result = execute_query(query)

    # Assuming the result is a dictionary representing the user details
    if result:
        role = result[0]['ROLE']

        if role == 'Customer':
            # Redirect to the customer index page
            return redirect('/customer_index')
        else:
            # Redirect to the default index page for non-customers
            return redirect('/default_index')

    # Return an error or handle the case where the login details are incorrect
    return "Invalid username or password"

def checkout():
    form = checkout()

    if form.validate_on_submit():
        # Assuming you have a 'customer_id' stored in the session
        customer_id = session.get('customer_id')
        card_number = form.card_number.data
        cvv = form.cvv.data
        zip_code = form.zip_code.data
        exp_date = form.exp_date.data
        address = form.address.data

        # Save payment information to the database (you might want to use an ORM for this)
        # Here, I'm using a simple SQL statement as an example
        sql = """
            INSERT INTO PAYMENT_INFO (PAYMENT_ID, CUSTOMER_ID, CARD_NUM, CVV, ZIP_CODE, EXP_DATE, ADDRESS)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """
        # Execute the SQL statement with the appropriate parameters

        return redirect('/thank-you')  # Redirect to a thank-you page after successful checkout

    return render_template('checkout.html', form=form)

def add_to_cart(isbn):
    # Get book details by ISBN (you might want to implement this function)
    book = get_book_details_by_isbn(isbn)

    # Initialize the cart in the session if it doesn't exist
    if 'cart' not in session:
        session['cart'] = []

    # Add the book details to the cart in the session
    session['cart'].append({
        'ISBN': book['ISBN'],
        'TITLE': book['TITLE'],
        'AUTHOR': book['AUTHOR'],
        'PRICE': book['PRICE']
        })
    return True



