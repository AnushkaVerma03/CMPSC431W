from flask import Flask, render_template, request, redirect, url_for, session

import service
from CheckoutPage import CheckoutForm



app = Flask(__name__)
app.config['TEMPLATES_AUTO_RELOAD'] = True

@app.route('/')
def index():
    return render_template("index.html")


@app.route('/books')
def books():
    books = service.get_books()
    return render_template('books.html', books=books)


@app.route('/contact-us')
def contact_us():
    return render_template('ContactUs.html')


@app.route('/accounts')
def accounts():
    return render_template('Account.html')


@app.route('/create_account', methods=['GET', 'POST'])
def create_account():
    # Your create account logic goes here
    return render_template('create_account.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    # Your login logic goes here
    return render_template('login.html')


@app.route('/shoppingcart')
def shopping_cart():
    # Check if the 'cart' key is present in the session
    if 'cart' in session:
        shopping_cart_items = session['cart']
    else:
        shopping_cart_items = []

    # Render the shopping cart template with the cart items
    return render_template('shoppingcart.html', shopping_cart_items=shopping_cart_items)
@app.route('/recommend-us')
def recommend_us():
    return render_template('RecommendUs.html')


# Add this route for submitting recommendations
@app.route('/submit-recommendation', methods=['POST'])
def submit_recommendation():
    book_isbn = request.form['isbn']
    book_name = request.form['bookName']
    author_name = request.form['authorName']
    recommendation = request.form['Recommendation']
    result = service.add_recommendation(book_isbn, book_name, author_name, recommendation)
    if result is not None:
        return 'Thanks for adding the book! You\'ve got great recommendations. Keep an eye on the email to get updates'
    else:
        return 'Sorry, we could not add the book. Please try again later.'

# def get_book_details_by_name(book_name):
# Assuming 'books' is your list of books
# for book in Books:
# if book['name'].lower() == book_name.replace('-', ' ').lower():
# return book

# Return None if the book is not found
# return None


@app.route('/book/<isbn>')
def book_detail_page(isbn):
    book = service.get_book_details_by_isbn(isbn)
    return render_template('book_details_page.html', book=book)


@app.route('/add_to_cart/<book_name>')
def add_to_cart(book_name):
    # Find the book by name
    # book = next((b for b in Books if b["name"] == book_name), None)

    # if book:
    # Add the book to the shopping cart
    # shopping_cart.append(book)

    return render_template('/books')



@app.route('/process_return', methods=['POST'])
def process_return():
    if request.method == 'POST':
        # Retrieve form data
        order_id = request.form['order_id']
        issue = request.form['issue']
        first_name = request.form['first_name']
        last_name = request.form['last_name']
        customer_id = request.form['customer_id']

        # TODO: Insert data into the ContactUs table
        # Uncomment and modify the code according to your database schema
        # Assuming you have a service method to handle database operations
        result = service.process_return(order_id, issue, first_name, last_name, customer_id)

        if result:
            # Redirect to a page confirming the return processing
            return render_template('return_processed.html', result='success', order_id=order_id)
        else:
            # Handle the case where return processing fails
            return render_template('return_processed.html', result='failure')

    # If the request method is not POST, you might want to handle it differently
    return redirect(url_for('index'))  # Redirect to the home page or another suitable route


@app.route('/refund_page')
def refund_page():
    # Logic for refund page goes here
    return render_template('refund_page.html')


@app.route('/replacement_page')
def replacement_page():
    # Logic for replacement page goes here
    return render_template('replacement_page.html')

@app.route('/add-to-cart/<isbn>')
def add_to_cart_route(isbn):
    success = add_to_cart(isbn)
    if success:
        book = service.get_book_details_by_isbn(isbn)
        return render_template('add_to_cart_success.html', book=book)
    else:
        return render_template('add_to_cart_failure.html')




if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=8000)
